Sample Event-Driven Web Application for the IBM Developer Works series:
http://www.ibm.com/developerworks/web/library/?series_title_by=reverse+ajax
